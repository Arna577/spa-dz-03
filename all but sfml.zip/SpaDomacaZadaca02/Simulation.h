#pragma once
class Simulation
{
};
