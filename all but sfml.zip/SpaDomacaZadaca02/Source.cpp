#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

// See: https://github.com/vanjavk/gdambic-rvs19-spa-dz-03
// See: https://rosettacode.org/wiki/Dijkstra%27s_algorithm

enum simulation_type {
	ZDTK1,
	ZDTK2
};

simulation_type type;
bool run = false;

static const sf::Color background_color(0, 0, 30);
static const sf::Keyboard::Key left_input = sf::Keyboard::Left;
static const sf::Keyboard::Key right_input = sf::Keyboard::Right;

uint32_t delta_ms = 0;
int interval_ms = 100;

void update(uint32_t delta) {
	delta_ms += delta;
	while (delta_ms >= interval_ms) {



		delta_ms -= interval_ms;
	}
}

int main()
{
	sf::RenderWindow window(sf::VideoMode(600, 400), "waow");
	window.setFramerateLimit(60);

	sf::Clock clock;

	std::cout << "LEFT MOUSE - add cells\n" << "RIGHT MOUSE - remove cells\n" << "MOUSE WHEEL - change mouse size\n" << "SPACEBAR - pause\n";
	std::cout << "\nno copyright :D - borna popovic\n";

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			switch (event.type) {
			case (sf::Event::Closed):
				window.close();
				break;
			case (sf::Event::KeyPressed):
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
				break;
			}
			if (event.type == sf::Event::MouseMoved) {
				//mouse_pos = window.mapPixelToCoords(sf::Mouse::getPosition(window));
			}
			if (event.type == sf::Event::MouseWheelMoved)
			{
				/*
				* mouse_size += event.mouseWheel.delta;
				 if (mouse_size < 1)
					 mouse_size = 1;
				 if (mouse_size > 32)
					 mouse_size = 32;
				*/
			}
			if (event.type == sf::Event::KeyPressed) {
				//if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
			}
		}

		window.clear(background_color);

		//auto begin = std::chrono::high_resolution_clock::now();
		uint32_t delta_ms = clock.restart().asMilliseconds();
		update(delta_ms);

		//auto end = std::chrono::high_resolution_clock::now();
		//const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin).count();
		//std::cout << ms << "ms" << std::endl;

		window.display();
	}

	return 0;
}