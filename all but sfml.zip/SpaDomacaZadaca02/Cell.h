#pragma once
template <typename T>

class Cell
{
private:
	T state;
public:
	void setState(const T new_state) {
		this->state = new_state;
	}
	T getState() {
		return this->state;
	}
	Cell<T>() {
		this->state = 0;
	}
	Cell(const T init_state) {
		this->state = init_state;
	}
};

